import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Layout from "@/components/layout/Layout";
import { getListings, getCategories } from "@/lib/storage";
import { Listing, Category } from "@/types";
import { translate, formatPrice, formatDate } from "@/lib/translations";

export default function Home() {
  const [featuredListings, setFeaturedListings] = useState<Listing[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    const listings = getListings();
    setFeaturedListings(listings.filter((listing) => listing.featured).slice(0, 6));
    setCategories(getCategories());
  }, []);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            {translate("Buy and Sell")} <span className="text-yellow-300">{translate("Anything")}</span><br />
            {translate("in Turkey")}
          </h1>
          <p className="text-xl max-w-2xl mx-auto mb-8 opacity-90">
            {translate("Turkey's marketplace for buying and selling new and used items - from cars and real estate to electronics and services.")}
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/listings/create">
              <Button size="lg" className="bg-yellow-500 hover:bg-yellow-400 text-black font-semibold">
                {translate("Post an Ad")}
              </Button>
            </Link>
            <Link to="/categories">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                {translate("Browse Categories")}
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Listings */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">{translate("Featured Listings")}</h2>
            <Link to="/featured" className="text-primary hover:underline">
              {translate("View All")}
            </Link>
          </div>

          {featuredListings.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredListings.map((listing) => (
                <Link to={`/listings/${listing.id}`} key={listing.id}>
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative h-48 bg-gray-100">
                      {listing.images && listing.images.length > 0 ? (
                        <img
                          src={listing.images[0]}
                          alt={listing.title}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center bg-gray-200 text-gray-400">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="48"
                            height="48"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                            <circle cx="9" cy="9" r="2" />
                            <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
                          </svg>
                        </div>
                      )}
                      <div className="absolute top-2 right-2 bg-yellow-500 text-black text-xs font-semibold px-2 py-1 rounded">
                        {translate("Featured")}
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-lg line-clamp-1">{listing.title}</h3>
                      <p className="text-primary text-lg font-semibold mt-1">
                        {formatPrice(listing.price)}
                      </p>
                      <div className="flex justify-between items-center mt-3 text-sm text-gray-500">
                        <span>{listing.location}</span>
                        <span>{formatDate(listing.createdAt)}</span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-white rounded-lg border">
              <p className="text-gray-500 mb-4">{translate("No featured listings yet.")}</p>
            </div>
          )}
        </div>
      </section>

      {/* Categories */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8">{translate("Browse by Category")}</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <Link
                to={`/categories/${category.slug}`}
                key={category.id}
                className="flex flex-col items-center p-6 rounded-lg bg-white hover:shadow-md transition-shadow border text-center"
              >
                <div className="w-16 h-16 flex items-center justify-center rounded-full bg-primary/10 text-primary mb-4">
                  {/* Icon placeholder - use actual category icons in production */}
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M16.88 3.5a2.6 2.6 0 0 1 0 3.75L6.12 18a2.6 2.6 0 1 1-3.75-3.75L13.13 3.5a2.6 2.6 0 0 1 3.75 0Z" />
                    <path d="m7.5 11.5 5 5" />
                    <path d="M16.88 3.5 20 6.62" />
                    <path d="m5 19 2.12 2.12" />
                  </svg>
                </div>
                <h3 className="font-medium">{translate(category.name)}</h3>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white rounded-xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-4">{translate("Ready to Sell?")}</h2>
              <p className="max-w-lg opacity-90 mb-6 md:mb-0">
                {translate("Post your ad for free and reach thousands of potential buyers. Upgrade to Featured to get more visibility!")}
              </p>
            </div>
            <Link to="/listings/create">
              <Button size="lg" className="bg-yellow-500 hover:bg-yellow-400 text-black font-semibold">
                {translate("Post an Ad Now")}
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}