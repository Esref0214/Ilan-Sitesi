export interface User {
  id: string;
  username: string;
  email: string;
  password: string; // In a real app with Supabase, we wouldn't store password like this
  phone?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  parentId?: string;
  subCategories?: Category[];
}

export interface Listing {
  id: string;
  title: string;
  description: string;
  price: number;
  images: string[];
  categoryId: string;
  subCategoryId?: string;
  userId: string;
  location: string;
  createdAt: string;
  updatedAt: string;
  isFeatured: boolean;
  featuredUntil?: string;
  status: 'active' | 'sold' | 'expired' | 'pending';
  views: number;
  contactPhone?: string;
  contactEmail?: string;
}