import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Layout from "@/components/layout/Layout";
import { translate } from "@/lib/translations";

export default function NotFound() {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="text-9xl font-bold text-gray-200">404</h1>
        <h2 className="text-3xl font-bold mt-6 mb-3">{translate("Page Not Found")}</h2>
        <p className="text-gray-600 mb-8 max-w-md mx-auto">
          {translate("The page you're looking for doesn't exist or has been moved.")}
        </p>
        <Link to="/">
          <Button size="lg">{translate("Back to Home")}</Button>
        </Link>
      </div>
    </Layout>
  );
}