import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { getCategoryBySlug, getSubcategories, getListingsByCategoryId } from "@/lib/storage";
import { Category, Listing } from "@/types";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function CategoryDetail() {
  const { slug, subSlug } = useParams();
  const [category, setCategory] = useState<Category | null>(null);
  const [subcategories, setSubcategories] = useState<Category[]>([]);
  const [listings, setListings] = useState<Listing[]>([]);
  const [activeTab, setActiveTab] = useState<string>("listings");
  
  useEffect(() => {
    if (slug) {
      const foundCategory = getCategoryBySlug(slug);
      if (foundCategory) {
        setCategory(foundCategory);
        setSubcategories(getSubcategories(foundCategory.id));
        
        // If there's a subSlug, find that subcategory
        if (subSlug) {
          const subcategory = getCategoryBySlug(subSlug);
          if (subcategory) {
            setListings(getListingsByCategoryId(subcategory.id));
          }
        } else {
          // Otherwise, get listings for the main category
          setListings(getListingsByCategoryId(foundCategory.id));
        }
      }
    }
  }, [slug, subSlug]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('tr-TR', { 
      style: 'currency', 
      currency: 'TRY',
      minimumFractionDigits: 0
    }).format(price);
  };
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('tr-TR', options);
  };

  if (!category) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h2 className="text-2xl font-bold mb-4">Category not found</h2>
          <p className="mb-6">The category you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link to="/categories">Browse all categories</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container py-8">
        <div className="mb-8">
          <nav className="flex mb-4">
            <ol className="flex items-center space-x-2 text-sm text-muted-foreground">
              <li>
                <Link to="/categories" className="hover:text-foreground">
                  Categories
                </Link>
              </li>
              <li className="mx-2">/</li>
              <li>
                <Link to={`/categories/${category.slug}`} className="hover:text-foreground">
                  {category.name}
                </Link>
              </li>
              {subSlug && (
                <>
                  <li className="mx-2">/</li>
                  <li className="font-medium text-foreground">{getCategoryBySlug(subSlug)?.name}</li>
                </>
              )}
            </ol>
          </nav>
          
          <h1 className="text-3xl font-bold">
            {subSlug ? getCategoryBySlug(subSlug)?.name : category.name}
          </h1>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="listings">Listings</TabsTrigger>
            {!subSlug && subcategories.length > 0 && (
              <TabsTrigger value="subcategories">Subcategories</TabsTrigger>
            )}
          </TabsList>
          
          <TabsContent value="listings">
            {listings.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {listings.map(listing => (
                  <Card key={listing.id} className="overflow-hidden">
                    <Link to={`/listings/${listing.id}`}>
                      <div className="aspect-video relative overflow-hidden">
                        {listing.images.length > 0 ? (
                          <img 
                            src={listing.images[0]} 
                            alt={listing.title} 
                            className="w-full h-full object-cover transition-transform hover:scale-105"
                          />
                        ) : (
                          <div className="w-full h-full bg-muted flex items-center justify-center">
                            No Image
                          </div>
                        )}
                        {listing.isFeatured && (
                          <Badge className="absolute top-2 right-2">Featured</Badge>
                        )}
                      </div>
                      <CardHeader className="p-4">
                        <CardTitle className="text-lg line-clamp-2">{listing.title}</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4 pt-0">
                        <p className="text-xl font-bold text-primary">{formatPrice(listing.price)}</p>
                        <p className="text-sm text-muted-foreground line-clamp-1">{listing.location}</p>
                      </CardContent>
                    </Link>
                    <CardFooter className="p-4 pt-0 flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">
                        {formatDate(listing.createdAt)}
                      </span>
                      <Badge variant="outline">{listing.status}</Badge>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground mb-4">No listings in this category yet.</p>
                <Link to="/listings/create">
                  <Button>Post an Ad</Button>
                </Link>
              </div>
            )}
          </TabsContent>
          
          {!subSlug && (
            <TabsContent value="subcategories">
              {subcategories.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {subcategories.map(subcategory => (
                    <Card key={subcategory.id}>
                      <Link to={`/categories/${category.slug}/${subcategory.slug}`}>
                        <CardHeader>
                          <CardTitle>{subcategory.name}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">
                            Browse all listings in this subcategory
                          </p>
                        </CardContent>
                      </Link>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">No subcategories available.</p>
                </div>
              )}
            </TabsContent>
          )}
        </Tabs>
      </div>
    </Layout>
  );
}