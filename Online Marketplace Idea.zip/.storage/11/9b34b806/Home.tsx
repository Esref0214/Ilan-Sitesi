import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getFeaturedListings, getCategoryTree } from "@/lib/storage";
import { Listing, Category } from "@/types";
import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Home() {
  const [featuredListings, setFeaturedListings] = useState<Listing[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  
  useEffect(() => {
    setFeaturedListings(getFeaturedListings());
    setCategories(getCategoryTree());
  }, []);
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('tr-TR', { 
      style: 'currency', 
      currency: 'TRY',
      minimumFractionDigits: 0
    }).format(price);
  };
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('tr-TR', options);
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-primary/10 to-primary/5 py-16 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Buy and Sell <span className="text-primary">Anything</span> in Turkey
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Turkey's marketplace for buying and selling new and used items - from cars and real estate to electronics and services.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/listings/create">
              <Button size="lg">Post an Ad</Button>
            </Link>
            <Link to="/categories">
              <Button variant="outline" size="lg">Browse Categories</Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Featured Listings */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold">Featured Listings</h2>
            <Link to="/listings/featured">
              <Button variant="ghost">View All</Button>
            </Link>
          </div>
          
          {featuredListings.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {featuredListings.map(listing => (
                <Card key={listing.id} className="overflow-hidden">
                  <Link to={`/listings/${listing.id}`}>
                    <div className="aspect-video relative overflow-hidden">
                      {listing.images.length > 0 ? (
                        <img 
                          src={listing.images[0]} 
                          alt={listing.title} 
                          className="w-full h-full object-cover transition-transform hover:scale-105"
                        />
                      ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                          No Image
                        </div>
                      )}
                      <Badge className="absolute top-2 right-2">Featured</Badge>
                    </div>
                    <CardHeader className="p-4">
                      <CardTitle className="text-lg line-clamp-2">{listing.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <p className="text-xl font-bold text-primary">{formatPrice(listing.price)}</p>
                      <p className="text-sm text-muted-foreground line-clamp-1">{listing.location}</p>
                    </CardContent>
                  </Link>
                  <CardFooter className="p-4 pt-0 flex justify-between items-center">
                    <span className="text-xs text-muted-foreground">
                      {formatDate(listing.createdAt)}
                    </span>
                    <Badge variant="outline">{listing.status}</Badge>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">No featured listings yet.</p>
              <Link to="/listings/create">
                <Button>Post an Ad</Button>
              </Link>
            </div>
          )}
        </div>
      </section>
      
      {/* Categories */}
      <section className="py-12 px-4 bg-secondary/10">
        <div className="container mx-auto">
          <h2 className="text-2xl font-bold mb-8">Browse by Category</h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {categories.map(category => (
              <Link 
                to={`/categories/${category.slug}`} 
                key={category.id}
                className="bg-card rounded-lg p-4 text-center hover:shadow-md transition-shadow"
              >
                <div className="mb-2">
                  {/* You can replace this with actual category icons */}
                  <div className="w-12 h-12 bg-primary/10 rounded-full mx-auto flex items-center justify-center">
                    <span className="text-primary font-semibold">
                      {category.name.charAt(0)}
                    </span>
                  </div>
                </div>
                <h3 className="font-medium">{category.name}</h3>
                {category.subCategories && (
                  <p className="text-xs text-muted-foreground mt-1">
                    {category.subCategories.length} subcategories
                  </p>
                )}
              </Link>
            ))}
          </div>
        </div>
      </section>
      
      {/* Call to Action */}
      <section className="py-16 px-4 bg-primary text-primary-foreground">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Sell?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Post your ad for free and reach thousands of potential buyers.
            Upgrade to Featured to get more visibility!
          </p>
          <Link to="/listings/create">
            <Button variant="secondary" size="lg">
              Post an Ad Now
            </Button>
          </Link>
        </div>
      </section>
    </Layout>
  );
}