import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { getFeaturedListings } from "@/lib/storage";
import { Listing } from "@/types";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function FeaturedListings() {
  const [listings, setListings] = useState<Listing[]>([]);
  
  useEffect(() => {
    setListings(getFeaturedListings());
  }, []);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('tr-TR', { 
      style: 'currency', 
      currency: 'TRY',
      minimumFractionDigits: 0
    }).format(price);
  };
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('tr-TR', options);
  };
  
  return (
    <Layout>
      <div className="container py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Featured Listings</h1>
        </div>
        
        {listings.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {listings.map(listing => (
              <Card key={listing.id} className="overflow-hidden">
                <Link to={`/listings/${listing.id}`}>
                  <div className="aspect-video relative overflow-hidden">
                    {listing.images.length > 0 ? (
                      <img 
                        src={listing.images[0]} 
                        alt={listing.title} 
                        className="w-full h-full object-cover transition-transform hover:scale-105"
                      />
                    ) : (
                      <div className="w-full h-full bg-muted flex items-center justify-center">
                        No Image
                      </div>
                    )}
                    <Badge className="absolute top-2 right-2">Featured</Badge>
                  </div>
                  <CardHeader className="p-4">
                    <CardTitle className="text-lg line-clamp-2">{listing.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <p className="text-xl font-bold text-primary">{formatPrice(listing.price)}</p>
                    <p className="text-sm text-muted-foreground line-clamp-1">{listing.location}</p>
                  </CardContent>
                </Link>
                <CardFooter className="p-4 pt-0 flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">
                    {formatDate(listing.createdAt)}
                  </span>
                  <Badge variant="outline">{listing.status}</Badge>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h2 className="text-2xl font-semibold mb-2">No Featured Listings Yet</h2>
            <p className="text-muted-foreground mb-6">
              Be the first to feature your listing and get more visibility!
            </p>
            <div className="flex justify-center gap-4">
              <Link to="/listings/create">
                <Button>Post an Ad</Button>
              </Link>
              <Link to="/">
                <Button variant="outline">Browse All Listings</Button>
              </Link>
            </div>
          </div>
        )}
        
        <div className="mt-12 p-6 border rounded-lg bg-secondary/10">
          <h2 className="text-xl font-semibold mb-4">Why Feature Your Ad?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <h3 className="font-medium">More Visibility</h3>
              <p className="text-muted-foreground">Featured ads appear at the top of search results and on the homepage.</p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Faster Sales</h3>
              <p className="text-muted-foreground">Featured ads sell up to 5 times faster than regular listings.</p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Stand Out</h3>
              <p className="text-muted-foreground">Make your listing stand out from the competition with a featured badge.</p>
            </div>
          </div>
          <div className="mt-6 text-center">
            <Link to="/pricing">
              <Button variant="outline">View Pricing</Button>
            </Link>
          </div>
        </div>
      </div>
    </Layout>
  );
}