import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { 
  getListingById, 
  getCategoryById, 
  getCurrentUser, 
  getUserById,
  setListingAsFeatured
} from "@/lib/storage";
import { Listing, User } from "@/types";
import { Mail, Phone, MapPin, Calendar, Eye, AlertTriangle } from "lucide-react";

export default function ListingDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [listing, setListing] = useState<Listing | null>(null);
  const [seller, setSeller] = useState<User | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isOwner, setIsOwner] = useState(false);
  const currentUser = getCurrentUser();
  
  useEffect(() => {
    if (id) {
      const foundListing = getListingById(id);
      if (foundListing) {
        setListing(foundListing);
        
        // Get seller info
        const listingSeller = getUserById(foundListing.userId);
        if (listingSeller) {
          setSeller(listingSeller);
        }
        
        // Check if current user is the owner
        if (currentUser && currentUser.id === foundListing.userId) {
          setIsOwner(true);
        }
        
        // Set first image as selected
        if (foundListing.images && foundListing.images.length > 0) {
          setSelectedImage(foundListing.images[0]);
        }
      }
    }
  }, [id, currentUser]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('tr-TR', { 
      style: 'currency', 
      currency: 'TRY',
      minimumFractionDigits: 0
    }).format(price);
  };
  
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('tr-TR', options);
  };
  
  const handlePromoteToFeatured = () => {
    if (id && listing) {
      // In a real app, this would go to a payment page
      // For demo purposes, we'll just make it featured for 7 days
      const featuredListing = setListingAsFeatured(id, 7);
      if (featuredListing) {
        setListing(featuredListing);
      }
    }
  };

  if (!listing) {
    return (
      <Layout>
        <div className="container py-16 text-center">
          <h2 className="text-2xl font-bold mb-4">Listing not found</h2>
          <p className="mb-6">The listing you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link to="/">Return to homepage</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const category = getCategoryById(listing.categoryId);

  return (
    <Layout>
      <div className="container py-8">
        {/* Breadcrumb */}
        <nav className="flex mb-6">
          <ol className="flex items-center space-x-2 text-sm text-muted-foreground">
            <li>
              <Link to="/" className="hover:text-foreground">Home</Link>
            </li>
            <li className="mx-2">/</li>
            {category && (
              <>
                <li>
                  <Link to={`/categories/${category.slug}`} className="hover:text-foreground">
                    {category.name}
                  </Link>
                </li>
                <li className="mx-2">/</li>
              </>
            )}
            <li className="font-medium text-foreground line-clamp-1">
              {listing.title}
            </li>
          </ol>
        </nav>
        
        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Images and Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Status Badge */}
            <div className="flex justify-between items-center">
              <h1 className="text-3xl font-bold">{listing.title}</h1>
              <Badge 
                variant={listing.status === 'active' ? "default" : "outline"}
                className="uppercase"
              >
                {listing.status}
              </Badge>
            </div>
            
            {/* Featured Badge */}
            {listing.isFeatured && (
              <div className="flex items-center gap-2 text-primary">
                <Badge variant="default">Featured</Badge>
                <span className="text-sm">
                  Featured until {formatDate(listing.featuredUntil || '')}
                </span>
              </div>
            )}
            
            {/* Image Gallery */}
            <div className="space-y-4">
              <Dialog>
                <DialogTrigger asChild>
                  <div 
                    className="aspect-video rounded-lg overflow-hidden cursor-pointer border bg-muted"
                  >
                    {selectedImage ? (
                      <img 
                        src={selectedImage} 
                        alt={listing.title} 
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full text-muted-foreground">
                        No images available
                      </div>
                    )}
                  </div>
                </DialogTrigger>
                <DialogContent className="max-w-4xl">
                  {selectedImage && (
                    <div className="aspect-auto">
                      <img 
                        src={selectedImage} 
                        alt={listing.title} 
                        className="w-full h-full object-contain"
                      />
                    </div>
                  )}
                </DialogContent>
              </Dialog>
              
              {/* Thumbnails */}
              {listing.images.length > 1 && (
                <div className="grid grid-cols-5 gap-2">
                  {listing.images.map((image, index) => (
                    <div 
                      key={index} 
                      className={`aspect-square rounded overflow-hidden border cursor-pointer ${
                        selectedImage === image ? 'ring-2 ring-primary' : ''
                      }`}
                      onClick={() => setSelectedImage(image)}
                    >
                      <img 
                        src={image} 
                        alt={`${listing.title} - ${index + 1}`} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            {/* Tabs for Description and Details */}
            <Tabs defaultValue="description" className="mt-8">
              <TabsList>
                <TabsTrigger value="description">Description</TabsTrigger>
                <TabsTrigger value="details">Details</TabsTrigger>
              </TabsList>
              <TabsContent value="description" className="mt-4 prose max-w-none">
                <div className="whitespace-pre-wrap">{listing.description}</div>
              </TabsContent>
              <TabsContent value="details" className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>Location: {listing.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>Posted on: {formatDate(listing.createdAt)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-muted-foreground" />
                    <span>Views: {listing.views}</span>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Right Column - Price and Contact Info */}
          <div className="space-y-6">
            {/* Price Card */}
            <Card>
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-primary mb-4">
                  {formatPrice(listing.price)}
                </div>
                
                {/* Owner Actions */}
                {isOwner ? (
                  <div className="space-y-4">
                    <div className="p-3 bg-yellow-50 text-yellow-800 rounded-md flex gap-2 items-start">
                      <AlertTriangle className="h-5 w-5" />
                      <p className="text-sm">This is your listing. You cannot contact yourself.</p>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <Button 
                        variant="outline" 
                        onClick={() => navigate(`/listings/${id}/edit`)}
                      >
                        Edit Listing
                      </Button>
                      
                      {!listing.isFeatured && (
                        <Button onClick={handlePromoteToFeatured}>
                          Promote to Featured
                        </Button>
                      )}
                    </div>
                  </div>
                ) : (
                  /* Contact Seller */
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Contact Information</h3>
                    
                    {listing.contactPhone && (
                      <div className="flex items-center gap-3">
                        <Phone className="h-5 w-5 text-primary" />
                        <a href={`tel:${listing.contactPhone}`} className="text-primary">
                          {listing.contactPhone}
                        </a>
                      </div>
                    )}
                    
                    {listing.contactEmail && (
                      <div className="flex items-center gap-3">
                        <Mail className="h-5 w-5 text-primary" />
                        <a href={`mailto:${listing.contactEmail}`} className="text-primary">
                          {listing.contactEmail}
                        </a>
                      </div>
                    )}
                    
                    {!listing.contactPhone && !listing.contactEmail && (
                      <p className="text-muted-foreground">
                        No contact information provided. Try sending a message.
                      </p>
                    )}
                    
                    <Button className="w-full">
                      Message Seller
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Seller Info */}
            {seller && (
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold text-lg mb-4">About the Seller</h3>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="font-semibold text-primary">
                        {seller.username.substring(0, 2).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">{seller.username}</p>
                      <p className="text-sm text-muted-foreground">
                        Member since {formatDate(seller.createdAt)}
                      </p>
                    </div>
                  </div>
                  {!isOwner && (
                    <Button variant="outline" className="w-full" asChild>
                      <Link to={`/seller/${seller.id}`}>
                        View All Ads by This Seller
                      </Link>
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
            
            {/* Safety Tips */}
            <div className="p-4 border rounded-lg bg-secondary/10">
              <h4 className="font-medium mb-2">Safety Tips</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Meet in public places for transactions</li>
                <li>• Check the item before paying</li>
                <li>• Don't send money in advance</li>
                <li>• Report suspicious listings</li>
              </ul>
            </div>
          </div>
        </div>
        
        {/* Report Listing */}
        <div className="mt-8 pt-4 border-t">
          <Button variant="ghost" size="sm" className="text-muted-foreground">
            Report this listing
          </Button>
        </div>
      </div>
    </Layout>
  );
}