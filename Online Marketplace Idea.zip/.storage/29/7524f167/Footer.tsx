import { Link } from "react-router-dom";
import { translate } from "@/lib/translations";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-50 border-t pt-12 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About Section */}
          <div>
            <h3 className="font-medium text-lg mb-3">{translate("About")}</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-gray-600 hover:text-primary">
                  {translate("About Us")}
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-gray-600 hover:text-primary">
                  {translate("Terms of Service")}
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-gray-600 hover:text-primary">
                  {translate("Privacy Policy")}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-600 hover:text-primary">
                  {translate("Contact Us")}
                </Link>
              </li>
            </ul>
          </div>

          {/* Categories Section */}
          <div>
            <h3 className="font-medium text-lg mb-3">{translate("Popular Categories")}</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/categories/real-estate" className="text-gray-600 hover:text-primary">
                  {translate("Real Estate")}
                </Link>
              </li>
              <li>
                <Link to="/categories/vehicles" className="text-gray-600 hover:text-primary">
                  {translate("Vehicles")}
                </Link>
              </li>
              <li>
                <Link to="/categories/electronics" className="text-gray-600 hover:text-primary">
                  {translate("Electronics")}
                </Link>
              </li>
              <li>
                <Link to="/categories/services" className="text-gray-600 hover:text-primary">
                  {translate("Services")}
                </Link>
              </li>
            </ul>
          </div>

          {/* For Sellers Section */}
          <div>
            <h3 className="font-medium text-lg mb-3">{translate("For Sellers")}</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/how-to-sell" className="text-gray-600 hover:text-primary">
                  {translate("How to Sell")}
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="text-gray-600 hover:text-primary">
                  {translate("Pricing & Features")}
                </Link>
              </li>
              <li>
                <Link to="/safety" className="text-gray-600 hover:text-primary">
                  {translate("Safety Tips")}
                </Link>
              </li>
            </ul>
          </div>

          {/* Social Links */}
          <div>
            <h3 className="font-medium text-lg mb-3">{translate("Follow Us")}</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-600 hover:text-primary">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                </svg>
              </a>
              <a href="#" className="text-gray-600 hover:text-primary">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                </svg>
              </a>
              <a href="#" className="text-gray-600 hover:text-primary">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                </svg>
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-12 pt-8 border-t text-center text-gray-500">
          &copy; {currentYear} İlanBurada. {translate("All rights reserved.")}
        </div>
      </div>
    </footer>
  );
}