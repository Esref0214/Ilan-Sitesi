import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// Pages
import Home from './pages/Home';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import CategoriesList from './pages/categories/CategoriesList';
import CategoryDetail from './pages/categories/CategoryDetail';
import CreateListing from './pages/listings/CreateListing';
import ListingDetail from './pages/listings/ListingDetail';
import FeaturedListings from './pages/listings/FeaturedListings';
import UserListings from './pages/dashboard/UserListings';
import NotFound from './pages/NotFound';

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          
          {/* Auth Routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          {/* Categories */}
          <Route path="/categories" element={<CategoriesList />} />
          <Route path="/categories/:slug" element={<CategoryDetail />} />
          <Route path="/categories/:slug/:subSlug" element={<CategoryDetail />} />
          
          {/* Listings */}
          <Route path="/listings/create" element={<CreateListing />} />
          <Route path="/listings/:id" element={<ListingDetail />} />
          <Route path="/listings/featured" element={<FeaturedListings />} />
          
          {/* Dashboard */}
          <Route path="/dashboard/listings" element={<UserListings />} />
          
          {/* 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;