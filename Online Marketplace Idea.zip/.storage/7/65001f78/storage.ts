import { User, Listing, Category } from "@/types";
import { v4 as uuidv4 } from 'uuid';

// LocalStorage keys
const USERS_KEY = 'classifieds_users';
const LISTINGS_KEY = 'classifieds_listings';
const CATEGORIES_KEY = 'classifieds_categories';
const CURRENT_USER_KEY = 'classifieds_current_user';

// Helper to get data from localStorage with default value
const getFromStorage = <T>(key: string, defaultValue: T): T => {
  const stored = localStorage.getItem(key);
  if (!stored) return defaultValue;
  try {
    return JSON.parse(stored) as T;
  } catch (e) {
    console.error(`Error parsing data from localStorage for key ${key}:`, e);
    return defaultValue;
  }
};

// Helper to set data to localStorage
const setToStorage = <T>(key: string, value: T): void => {
  localStorage.setItem(key, JSON.stringify(value));
};

// User methods
export const getUsers = (): User[] => getFromStorage<User[]>(USERS_KEY, []);

export const getUserById = (id: string): User | undefined => {
  return getUsers().find(user => user.id === id);
};

export const getUserByEmail = (email: string): User | undefined => {
  return getUsers().find(user => user.email === email);
};

export const createUser = (user: Omit<User, 'id' | 'createdAt'>): User => {
  const newUser: User = {
    ...user,
    id: uuidv4(),
    createdAt: new Date().toISOString()
  };
  
  const users = getUsers();
  users.push(newUser);
  setToStorage(USERS_KEY, users);
  
  return newUser;
};

export const updateUser = (user: User): User => {
  const users = getUsers();
  const index = users.findIndex(u => u.id === user.id);
  
  if (index !== -1) {
    users[index] = user;
    setToStorage(USERS_KEY, users);
  }
  
  return user;
};

// Authentication methods
export const getCurrentUser = (): User | null => {
  const userId = localStorage.getItem(CURRENT_USER_KEY);
  if (!userId) return null;
  
  const user = getUserById(userId);
  return user || null;
};

export const setCurrentUser = (userId: string): void => {
  localStorage.setItem(CURRENT_USER_KEY, userId);
};

export const logoutUser = (): void => {
  localStorage.removeItem(CURRENT_USER_KEY);
};

// Listing methods
export const getListings = (): Listing[] => getFromStorage<Listing[]>(LISTINGS_KEY, []);

export const getListingById = (id: string): Listing | undefined => {
  return getListings().find(listing => listing.id === id);
};

export const getListingsByUserId = (userId: string): Listing[] => {
  return getListings().filter(listing => listing.userId === userId);
};

export const getListingsByCategoryId = (categoryId: string): Listing[] => {
  return getListings().filter(
    listing => listing.categoryId === categoryId || listing.subCategoryId === categoryId
  );
};

export const getFeaturedListings = (): Listing[] => {
  const now = new Date().toISOString();
  return getListings().filter(
    listing => listing.isFeatured && 
               (!listing.featuredUntil || listing.featuredUntil > now) &&
               listing.status === 'active'
  );
};

export const createListing = (listing: Omit<Listing, 'id' | 'createdAt' | 'updatedAt' | 'views'>): Listing => {
  const now = new Date().toISOString();
  const newListing: Listing = {
    ...listing,
    id: uuidv4(),
    createdAt: now,
    updatedAt: now,
    views: 0
  };
  
  const listings = getListings();
  listings.push(newListing);
  setToStorage(LISTINGS_KEY, listings);
  
  return newListing;
};

export const updateListing = (listing: Listing): Listing => {
  const listings = getListings();
  const index = listings.findIndex(l => l.id === listing.id);
  
  if (index !== -1) {
    listings[index] = {
      ...listing,
      updatedAt: new Date().toISOString()
    };
    setToStorage(LISTINGS_KEY, listings);
  }
  
  return listing;
};

export const deleteListing = (id: string): void => {
  const listings = getListings();
  const filteredListings = listings.filter(listing => listing.id !== id);
  setToStorage(LISTINGS_KEY, filteredListings);
};

// Category methods
export const getCategories = (): Category[] => {
  const categories = getFromStorage<Category[]>(CATEGORIES_KEY, []);
  if (categories.length === 0) {
    // Initialize with default categories
    const defaultCategories = initializeDefaultCategories();
    setToStorage(CATEGORIES_KEY, defaultCategories);
    return defaultCategories;
  }
  return categories;
};

export const getCategoryById = (id: string): Category | undefined => {
  return getCategories().find(category => category.id === id);
};

export const getCategoryBySlug = (slug: string): Category | undefined => {
  return getCategories().find(category => category.slug === slug);
};

export const getSubcategories = (parentId: string): Category[] => {
  return getCategories().filter(category => category.parentId === parentId);
};

export const createCategory = (category: Omit<Category, 'id'>): Category => {
  const newCategory: Category = {
    ...category,
    id: uuidv4()
  };
  
  const categories = getCategories();
  categories.push(newCategory);
  setToStorage(CATEGORIES_KEY, categories);
  
  return newCategory;
};

export const initializeDefaultCategories = (): Category[] => {
  // Root categories
  const realEstate: Category = { id: uuidv4(), name: 'Real Estate', slug: 'real-estate' };
  const vehicles: Category = { id: uuidv4(), name: 'Vehicles', slug: 'vehicles' };
  const electronics: Category = { id: uuidv4(), name: 'Electronics', slug: 'electronics' };
  const homeGarden: Category = { id: uuidv4(), name: 'Home & Garden', slug: 'home-garden' };
  const fashion: Category = { id: uuidv4(), name: 'Fashion', slug: 'fashion' };
  const services: Category = { id: uuidv4(), name: 'Services', slug: 'services' };
  
  // Real Estate subcategories
  const apartments: Category = { id: uuidv4(), name: 'Apartments', slug: 'apartments', parentId: realEstate.id };
  const houses: Category = { id: uuidv4(), name: 'Houses', slug: 'houses', parentId: realEstate.id };
  const land: Category = { id: uuidv4(), name: 'Land', slug: 'land', parentId: realEstate.id };
  const commercial: Category = { id: uuidv4(), name: 'Commercial', slug: 'commercial', parentId: realEstate.id };
  
  // Vehicles subcategories
  const cars: Category = { id: uuidv4(), name: 'Cars', slug: 'cars', parentId: vehicles.id };
  const motorcycles: Category = { id: uuidv4(), name: 'Motorcycles', slug: 'motorcycles', parentId: vehicles.id };
  const boats: Category = { id: uuidv4(), name: 'Boats', slug: 'boats', parentId: vehicles.id };
  const parts: Category = { id: uuidv4(), name: 'Auto Parts', slug: 'auto-parts', parentId: vehicles.id };
  
  // Electronics subcategories
  const phones: Category = { id: uuidv4(), name: 'Phones', slug: 'phones', parentId: electronics.id };
  const computers: Category = { id: uuidv4(), name: 'Computers', slug: 'computers', parentId: electronics.id };
  const tvAudio: Category = { id: uuidv4(), name: 'TV & Audio', slug: 'tv-audio', parentId: electronics.id };
  const gaming: Category = { id: uuidv4(), name: 'Gaming', slug: 'gaming', parentId: electronics.id };
  
  return [
    realEstate, vehicles, electronics, homeGarden, fashion, services,
    apartments, houses, land, commercial,
    cars, motorcycles, boats, parts,
    phones, computers, tvAudio, gaming
  ];
};

// Helper to build category tree
export const getCategoryTree = (): Category[] => {
  const allCategories = getCategories();
  const rootCategories = allCategories.filter(c => !c.parentId);
  
  return rootCategories.map(root => {
    const subCategories = allCategories.filter(c => c.parentId === root.id);
    return { ...root, subCategories };
  });
};

// Featured/showcase listings
export const setListingAsFeatured = (listingId: string, durationInDays: number): Listing | undefined => {
  const listing = getListingById(listingId);
  if (!listing) return undefined;
  
  const featuredUntil = new Date();
  featuredUntil.setDate(featuredUntil.getDate() + durationInDays);
  
  const updatedListing: Listing = {
    ...listing,
    isFeatured: true,
    featuredUntil: featuredUntil.toISOString()
  };
  
  return updateListing(updatedListing);
};