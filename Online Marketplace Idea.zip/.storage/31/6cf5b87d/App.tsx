import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useEffect } from 'react';
import Index from './pages/Home';
import NotFound from './pages/NotFound';

// Auth Pages
import Register from './pages/auth/Register';
import Login from './pages/auth/Login';

// Category Pages
import CategoriesList from './pages/categories/CategoriesList';
import CategoryDetail from './pages/categories/CategoryDetail';

// Listing Pages
import CreateListing from './pages/listings/CreateListing';
import ListingDetail from './pages/listings/ListingDetail';
import FeaturedListings from './pages/listings/FeaturedListings';

// Dashboard Pages
import UserListings from './pages/dashboard/UserListings';

// Initialize database with sample data if needed
import { initializeDatabase } from './lib/storage';

const queryClient = new QueryClient();

const App = () => {
  useEffect(() => {
    // Initialize local storage data if empty
    initializeDatabase();
  }, []);
  
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            
            {/* Auth Routes */}
            <Route path="/register" element={<Register />} />
            <Route path="/login" element={<Login />} />
            
            {/* Category Routes */}
            <Route path="/categories" element={<CategoriesList />} />
            <Route path="/categories/:slug" element={<CategoryDetail />} />
            
            {/* Listing Routes */}
            <Route path="/listings/create" element={<CreateListing />} />
            <Route path="/listings/:id" element={<ListingDetail />} />
            <Route path="/featured" element={<FeaturedListings />} />
            
            {/* Dashboard Routes */}
            <Route path="/dashboard" element={<UserListings />} />
            
            {/* 404 Route */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;