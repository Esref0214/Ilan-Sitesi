// Turkish translations for the classified ads website

export const translations = {
  // Navbar
  "Post Ad": "İlan Ver",
  "Categories": "Kategoriler",
  "Featured": "Öne Çıkanlar",
  "Search listings...": "İlanlarda ara...",
  "Log In": "Giriş Yap",
  "Register": "Kayıt Ol",
  "My Listings": "İlanlarım",
  "Profile": "Profil",
  "Favorites": "Favorilerim",
  "Log out": "Çıkış Yap",
  
  // Home Page
  "Buy and Sell": "Alım ve Satım",
  "Anything": "Her Şey",
  "in Turkey": "Türkiye'de",
  "Turkey's marketplace for buying and selling new and used items - from cars and real estate to electronics and services.": "Türkiye'nin yeni ve ikinci el ürünlerin alım satımı için pazaryeri - arabalardan gayrimenkule, elektronikten hizmetlere kadar.",
  "Post an Ad": "İlan Ver",
  "Browse Categories": "Kategorilere Göz At",
  "Featured Listings": "Öne Çıkan İlanlar",
  "View All": "Tümünü Görüntüle",
  "No featured listings yet.": "Henüz öne çıkan ilan yok.",
  "Browse by Category": "Kategoriye Göre Göz At",
  "Ready to Sell?": "Satmaya Hazır mısın?",
  "Post your ad for free and reach thousands of potential buyers. Upgrade to Featured to get more visibility!": "İlanını ücretsiz yayınla ve binlerce potansiyel alıcıya ulaş. Daha fazla görünürlük için Öne Çıkan'a yükselt!",
  "Post an Ad Now": "Hemen İlan Ver",
  
  // Auth Pages
  "Welcome back": "Tekrar Hoşgeldin",
  "Enter your credentials to sign in to your account": "Hesabına giriş yapmak için bilgilerini gir",
  "Email": "E-posta",
  "Password": "Şifre",
  "Sign In": "Giriş Yap",
  "Don't have an account?": "Hesabın yok mu?",
  "Create an account": "Hesap oluştur",
  "Enter your details to create your account": "Hesap oluşturmak için bilgilerini gir",
  "Username": "Kullanıcı adı",
  "Phone (Optional)": "Telefon (İsteğe bağlı)",
  "Confirm Password": "Şifreyi Onayla",
  "Already have an account?": "Zaten hesabın var mı?",
  
  // Listing Creation
  "Post a New Ad": "Yeni İlan Yayınla",
  "Title": "Başlık",
  "A clear, descriptive title will attract more viewers.": "Net ve açıklayıcı bir başlık daha fazla görüntülenme çeker.",
  "Category": "Kategori",
  "Select a category": "Kategori seç",
  "Subcategory": "Alt Kategori",
  "Select a subcategory": "Alt kategori seç",
  "Price (TRY)": "Fiyat (TL)",
  "Location": "Konum",
  "Description": "Açıklama",
  "Include information about condition, features, and any other relevant details.": "Durum, özellikler ve diğer ilgili detaylar hakkında bilgi ekleyin.",
  "Contact Phone (Optional)": "İletişim Telefonu (İsteğe bağlı)",
  "How interested buyers can contact you by phone.": "İlgilenen alıcıların telefonla size nasıl ulaşabileceği.",
  "Contact Email (Optional)": "İletişim E-postası (İsteğe bağlı)",
  "How interested buyers can contact you by email.": "İlgilenen alıcıların e-posta ile size nasıl ulaşabileceği.",
  "Upload Images": "Fotoğraf Yükle",
  "Add photos of your item. Up to 10 images.": "Ürününüzün fotoğraflarını ekleyin. 10 adete kadar.",
  
  // Categories
  "Real Estate": "Emlak",
  "Vehicles": "Vasıta",
  "Electronics": "Elektronik",
  "Home & Garden": "Ev ve Bahçe",
  "Fashion": "Moda",
  "Services": "Hizmetler",
  
  // Real Estate subcategories
  "Apartments": "Daireler",
  "Houses": "Evler",
  "Land": "Arsa",
  "Commercial": "Ticari",
  
  // Vehicles subcategories
  "Cars": "Otomobiller",
  "Motorcycles": "Motosikletler",
  "Boats": "Tekneler",
  "Auto Parts": "Oto Yedek Parça",
  
  // Electronics subcategories
  "Phones": "Telefonlar",
  "Computers": "Bilgisayarlar",
  "TV & Audio": "TV ve Ses",
  "Gaming": "Oyun",
  
  // Listing Details
  "Contact Information": "İletişim Bilgileri",
  "Message Seller": "Satıcıya Mesaj Gönder",
  "About the Seller": "Satıcı Hakkında",
  "Member since": "Üyelik tarihi",
  "View All Ads by This Seller": "Bu Satıcının Tüm İlanları",
  "Safety Tips": "Güvenlik İpuçları",
  "Meet in public places for transactions": "İşlemler için halka açık yerlerde buluşun",
  "Check the item before paying": "Ödeme yapmadan önce ürünü kontrol edin",
  "Don't send money in advance": "Önceden para göndermeyin",
  "Report suspicious listings": "Şüpheli ilanları bildirin",
  "Report this listing": "Bu ilanı bildir",
  
  // Featured Listings
  "No Featured Listings Yet": "Henüz Öne Çıkan İlan Yok",
  "Be the first to feature your listing and get more visibility!": "İlanınızı öne çıkaran ilk kişi olun ve daha fazla görünürlük kazanın!",
  "Why Feature Your Ad?": "İlanınızı Neden Öne Çıkarmalısınız?",
  "More Visibility": "Daha Fazla Görünürlük",
  "Featured ads appear at the top of search results and on the homepage.": "Öne çıkan ilanlar arama sonuçlarında ve ana sayfada üstte görünür.",
  "Faster Sales": "Daha Hızlı Satış",
  "Featured ads sell up to 5 times faster than regular listings.": "Öne çıkan ilanlar normal ilanlardan 5 kata kadar daha hızlı satılır.",
  "Stand Out": "Öne Çıkın",
  "Make your listing stand out from the competition with a featured badge.": "İlanınızı öne çıkan rozeti ile rekabetten ayırın.",
  "View Pricing": "Fiyatlandırmayı Görüntüle",
  
  // User Dashboard
  "My Listings": "İlanlarım",
  "Post New Ad": "Yeni İlan Ver",
  "No Listings Yet": "Henüz İlan Yok",
  "You haven't posted any listings yet. Create your first ad now!": "Henüz hiç ilan yayınlamadınız. İlk ilanınızı şimdi oluşturun!",
  "Post Your First Ad": "İlk İlanınızı Yayınlayın",
  "Title": "Başlık",
  "Price": "Fiyat",
  "Status": "Durum",
  "Posted": "Yayınlanma",
  "Views": "Görüntülenme",
  "Actions": "İşlemler",
  "View": "Görüntüle",
  "Edit": "Düzenle",
  "Delete": "Sil",
  "Promote to Featured": "Öne Çıkarana Yükselt",
  "Are you sure?": "Emin misiniz?",
  "This will permanently delete your listing. This action cannot be undone.": "Bu işlem ilanınızı kalıcı olarak silecektir. Bu işlem geri alınamaz.",
  "Cancel": "İptal",
  
  // Status labels
  "active": "aktif",
  "sold": "satıldı",
  "expired": "süresi doldu",
  "pending": "beklemede",
  
  // Footer
  "About": "Hakkında",
  "About Us": "Hakkımızda",
  "Terms of Service": "Kullanım Koşulları",
  "Privacy Policy": "Gizlilik Politikası",
  "Contact Us": "Bize Ulaşın",
  "Popular Categories": "Popüler Kategoriler",
  "For Sellers": "Satıcılar İçin",
  "How to Sell": "Nasıl Satılır",
  "Pricing & Features": "Fiyatlandırma ve Özellikler",
  "Safety Tips": "Güvenlik İpuçları",
  "Follow Us": "Bizi Takip Edin",
  "All rights reserved.": "Tüm hakları saklıdır.",
  
  // 404 Page
  "Page Not Found": "Sayfa Bulunamadı",
  "The page you're looking for doesn't exist or has been moved.": "Aradığınız sayfa mevcut değil veya taşınmış.",
  "Back to Home": "Ana Sayfaya Dön"
};

export const translate = (key: string): string => {
  return translations[key as keyof typeof translations] || key;
};

// Helper function to format currency in Turkish Lira
export const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('tr-TR', { 
    style: 'currency', 
    currency: 'TRY',
    minimumFractionDigits: 0
  }).format(price);
};

// Helper function to format dates in Turkish
export const formatDate = (dateString: string): string => {
  const options: Intl.DateTimeFormatOptions = { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  };
  return new Date(dateString).toLocaleDateString('tr-TR', options);
};