import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { getCategoryTree } from "@/lib/storage";
import { Category } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export default function CategoriesList() {
  const [categories, setCategories] = useState<Category[]>([]);
  
  useEffect(() => {
    setCategories(getCategoryTree());
  }, []);

  return (
    <Layout>
      <div className="container py-8">
        <h1 className="text-3xl font-bold mb-8">Browse Categories</h1>
        
        <div className="grid gap-8">
          {categories.map((category) => (
            <Card key={category.id}>
              <CardHeader>
                <CardTitle>
                  <Link to={`/categories/${category.slug}`} className="text-xl hover:text-primary">
                    {category.name}
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {category.subCategories && category.subCategories.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                    {category.subCategories.map((subCategory) => (
                      <Link
                        key={subCategory.id}
                        to={`/categories/${category.slug}/${subCategory.slug}`}
                        className="p-2 hover:bg-secondary/30 rounded-md"
                      >
                        {subCategory.name}
                      </Link>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No subcategories available.</p>
                )}
              </CardContent>
              <Separator />
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}