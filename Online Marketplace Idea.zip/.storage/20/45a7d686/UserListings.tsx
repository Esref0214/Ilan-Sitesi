import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { getListingsByUserId, getCurrentUser, deleteListing } from "@/lib/storage";
import { Listing } from "@/types";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal } from "lucide-react";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function UserListings() {
  const navigate = useNavigate();
  const [listings, setListings] = useState<Listing[]>([]);
  const [listingToDelete, setListingToDelete] = useState<string | null>(null);
  const currentUser = getCurrentUser();
  
  useEffect(() => {
    if (!currentUser) {
      navigate("/login");
      return;
    }
    
    setListings(getListingsByUserId(currentUser.id));
  }, [navigate, currentUser]);
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('tr-TR', { 
      style: 'currency', 
      currency: 'TRY',
      minimumFractionDigits: 0
    }).format(price);
  };
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('tr-TR');
  };
  
  const handleDelete = () => {
    if (listingToDelete) {
      deleteListing(listingToDelete);
      setListings(listings.filter(listing => listing.id !== listingToDelete));
      setListingToDelete(null);
    }
  };
  
  const getStatusBadgeVariant = (status: string) => {
    switch(status) {
      case 'active':
        return 'default';
      case 'sold':
        return 'success';
      case 'expired':
        return 'secondary';
      case 'pending':
        return 'warning';
      default:
        return 'outline';
    }
  };

  if (!currentUser) return null;

  return (
    <Layout>
      <div className="container py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">My Listings</h1>
          <Button asChild>
            <Link to="/listings/create">Post New Ad</Link>
          </Button>
        </div>
        
        {listings.length > 0 ? (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Posted</TableHead>
                  <TableHead>Views</TableHead>
                  <TableHead className="w-[80px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {listings.map((listing) => (
                  <TableRow key={listing.id}>
                    <TableCell>
                      <div>
                        <Link 
                          to={`/listings/${listing.id}`}
                          className="font-medium hover:underline"
                        >
                          {listing.title}
                        </Link>
                        {listing.isFeatured && (
                          <Badge className="ml-2" variant="secondary">
                            Featured
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{formatPrice(listing.price)}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadgeVariant(listing.status)}>
                        {listing.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{formatDate(listing.createdAt)}</TableCell>
                    <TableCell>{listing.views}</TableCell>
                    <TableCell>
                      <AlertDialog open={listingToDelete === listing.id} onOpenChange={(open) => {
                        if (!open) setListingToDelete(null);
                      }}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem asChild>
                              <Link to={`/listings/${listing.id}`}>View</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link to={`/listings/${listing.id}/edit`}>Edit</Link>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            {!listing.isFeatured && (
                              <DropdownMenuItem asChild>
                                <Link to={`/listings/${listing.id}/promote`}>Promote to Featured</Link>
                              </DropdownMenuItem>
                            )}
                            <AlertDialogTrigger asChild>
                              <DropdownMenuItem className="text-red-600" onSelect={() => setListingToDelete(listing.id)}>
                                Delete
                              </DropdownMenuItem>
                            </AlertDialogTrigger>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will permanently delete your listing. This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="text-center py-16 border rounded-lg">
            <h2 className="text-2xl font-semibold mb-2">No Listings Yet</h2>
            <p className="text-muted-foreground mb-6">
              You haven't posted any listings yet. Create your first ad now!
            </p>
            <Button asChild>
              <Link to="/listings/create">Post Your First Ad</Link>
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}