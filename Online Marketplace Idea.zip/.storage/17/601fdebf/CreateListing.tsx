import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  getCategoryTree,
  getSubcategories,
  createListing,
  getCurrentUser,
} from "@/lib/storage";
import { Category } from "@/types";

const createListingSchema = z.object({
  title: z.string().min(5, {
    message: "Title must be at least 5 characters.",
  }).max(100, {
    message: "Title must not exceed 100 characters."
  }),
  description: z.string().min(20, {
    message: "Description must be at least 20 characters.",
  }).max(5000, {
    message: "Description must not exceed 5000 characters."
  }),
  price: z.coerce.number().positive({
    message: "Price must be positive.",
  }),
  categoryId: z.string({
    required_error: "Please select a category.",
  }),
  subCategoryId: z.string().optional(),
  location: z.string().min(3, {
    message: "Location must be at least 3 characters.",
  }),
  contactPhone: z.string().optional(),
  contactEmail: z.string().email().optional(),
  images: z.any().optional(), // In a real app, we'd handle file uploads
});

type CreateListingFormValues = z.infer<typeof createListingSchema>;

export default function CreateListing() {
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Category[]>([]);
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const currentUser = getCurrentUser();

  useEffect(() => {
    if (!currentUser) {
      navigate("/login", { state: { from: "/listings/create" } });
    }
    setCategories(getCategoryTree());
  }, [navigate, currentUser]);

  const form = useForm<CreateListingFormValues>({
    resolver: zodResolver(createListingSchema),
    defaultValues: {
      title: "",
      description: "",
      price: undefined,
      categoryId: "",
      subCategoryId: "",
      location: "",
      contactPhone: currentUser?.phone || "",
      contactEmail: currentUser?.email || "",
      images: undefined,
    },
  });
  
  const selectedCategoryId = form.watch("categoryId");
  
  useEffect(() => {
    if (selectedCategoryId) {
      setSubcategories(getSubcategories(selectedCategoryId));
      form.setValue("subCategoryId", "");
    }
  }, [selectedCategoryId, form]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    // In a real app, we'd upload these to cloud storage
    // For now, we'll create object URLs for demo purposes
    const newUrls: string[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const url = URL.createObjectURL(file);
      newUrls.push(url);
    }
    
    setImageUrls([...imageUrls, ...newUrls]);
  };

  const onSubmit = (values: CreateListingFormValues) => {
    if (!currentUser) {
      setError("You must be logged in to post a listing.");
      return;
    }
    
    try {
      const listing = createListing({
        title: values.title,
        description: values.description,
        price: values.price,
        categoryId: values.categoryId,
        subCategoryId: values.subCategoryId,
        location: values.location,
        userId: currentUser.id,
        images: imageUrls,
        isFeatured: false,
        status: 'active',
        contactPhone: values.contactPhone,
        contactEmail: values.contactEmail,
      });
      
      navigate(`/listings/${listing.id}`);
    } catch (err) {
      setError("An error occurred while creating your listing. Please try again.");
      console.error(err);
    }
  };
  
  const removeImage = (index: number) => {
    const newUrls = [...imageUrls];
    newUrls.splice(index, 1);
    setImageUrls(newUrls);
  };

  return (
    <Layout>
      <div className="container py-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Post a New Ad</h1>
          
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <div className="bg-card border rounded-lg p-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Title */}
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 2020 Toyota Corolla in excellent condition" {...field} />
                      </FormControl>
                      <FormDescription>
                        A clear, descriptive title will attract more viewers.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Category */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="categoryId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories.map(category => (
                              <SelectItem key={category.id} value={category.id}>
                                {category.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {/* Subcategory (shown only when a category is selected) */}
                  {subcategories.length > 0 && (
                    <FormField
                      control={form.control}
                      name="subCategoryId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Subcategory</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a subcategory" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {subcategories.map(subcategory => (
                                <SelectItem key={subcategory.id} value={subcategory.id}>
                                  {subcategory.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                </div>
                
                {/* Price & Location */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price (TRY)</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Istanbul, Kadikoy" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                {/* Description */}
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe your item in detail..." 
                          className="min-h-32" 
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription>
                        Include information about condition, features, and any other relevant details.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Contact Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="contactPhone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Phone (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="+90 555 123 4567" {...field} />
                        </FormControl>
                        <FormDescription>
                          How interested buyers can contact you by phone.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="contactEmail"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Email (Optional)</FormLabel>
                        <FormControl>
                          <Input type="email" {...field} />
                        </FormControl>
                        <FormDescription>
                          How interested buyers can contact you by email.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                {/* Image Upload */}
                <div className="space-y-3">
                  <div>
                    <FormLabel htmlFor="images">Upload Images</FormLabel>
                    <FormDescription>
                      Add photos of your item. Up to 10 images.
                    </FormDescription>
                  </div>
                  
                  <div className="mt-2">
                    <Input 
                      id="images" 
                      type="file" 
                      accept="image/*" 
                      multiple 
                      onChange={handleImageUpload}
                      disabled={imageUrls.length >= 10}
                    />
                  </div>
                  
                  {imageUrls.length > 0 && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
                      {imageUrls.map((url, index) => (
                        <div key={index} className="relative aspect-square">
                          <img 
                            src={url} 
                            alt={`Uploaded ${index + 1}`}
                            className="w-full h-full object-cover rounded-md"
                          />
                          <Button
                            type="button"
                            size="sm"
                            variant="destructive"
                            className="absolute top-1 right-1 h-6 w-6 p-0"
                            onClick={() => removeImage(index)}
                          >
                            ×
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                <Button type="submit" className="w-full">
                  Post Ad
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </Layout>
  );
}