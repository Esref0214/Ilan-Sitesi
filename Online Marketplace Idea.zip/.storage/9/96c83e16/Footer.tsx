import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <h5 className="font-semibold text-lg mb-4">About</h5>
            <ul className="space-y-2">
              <li><Link to="/about" className="text-muted-foreground hover:text-foreground">About Us</Link></li>
              <li><Link to="/terms" className="text-muted-foreground hover:text-foreground">Terms of Service</Link></li>
              <li><Link to="/privacy" className="text-muted-foreground hover:text-foreground">Privacy Policy</Link></li>
              <li><Link to="/contact" className="text-muted-foreground hover:text-foreground">Contact Us</Link></li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-semibold text-lg mb-4">Popular Categories</h5>
            <ul className="space-y-2">
              <li><Link to="/categories/real-estate" className="text-muted-foreground hover:text-foreground">Real Estate</Link></li>
              <li><Link to="/categories/vehicles" className="text-muted-foreground hover:text-foreground">Vehicles</Link></li>
              <li><Link to="/categories/electronics" className="text-muted-foreground hover:text-foreground">Electronics</Link></li>
              <li><Link to="/categories/services" className="text-muted-foreground hover:text-foreground">Services</Link></li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-semibold text-lg mb-4">For Sellers</h5>
            <ul className="space-y-2">
              <li><Link to="/how-to-sell" className="text-muted-foreground hover:text-foreground">How to Sell</Link></li>
              <li><Link to="/listings/create" className="text-muted-foreground hover:text-foreground">Post an Ad</Link></li>
              <li><Link to="/pricing" className="text-muted-foreground hover:text-foreground">Pricing & Features</Link></li>
              <li><Link to="/safety" className="text-muted-foreground hover:text-foreground">Safety Tips</Link></li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-semibold text-lg mb-4">Follow Us</h5>
            <ul className="space-y-2">
              <li><a href="#" className="text-muted-foreground hover:text-foreground">Facebook</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-foreground">Twitter</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-foreground">Instagram</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-foreground">LinkedIn</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t text-center text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} SatilikCom. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}